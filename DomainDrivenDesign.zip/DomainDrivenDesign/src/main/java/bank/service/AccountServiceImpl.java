package bank.service;

import bank.domain.Account;
import bank.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    @Autowired
    public AccountServiceImpl(AccountRepository repo) {
        this.accountRepository = repo;
    }

    @Override
    public Account createAccount(String accountNumber, Double initialBalance) {
        return accountRepository.save(new Account(accountNumber, initialBalance));
    }

    @Override
    public Double viewBalance(String accountNumber) {
        Account acc = accountRepository.findByAccountNumber(accountNumber);
        return acc != null ? acc.getBalance() : null;
    }

    @Override
    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }
}
