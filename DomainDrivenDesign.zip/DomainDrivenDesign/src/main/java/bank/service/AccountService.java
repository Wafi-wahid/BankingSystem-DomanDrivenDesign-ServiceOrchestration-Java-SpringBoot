package bank.service;

import bank.domain.Account;

import java.util.List;

public interface AccountService {
    Account createAccount(String accountNumber, Double initialBalance);
    Double viewBalance(String accountNumber);
    List<Account> getAllAccounts();
}
